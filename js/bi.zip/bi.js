    // 闭包一
(function($,window,document,undefined){
     // 超过指定数值 改变字体颜色
    function colorChange(value,ele){
      //在需要改变颜色的元素添加id值，并获取
        var elet = "#"+ele;
        var elevalue = $(elet).html();
        var newstr=elevalue.replace(/%/, "");
        return newstr>value?true:false;
    }

    function initColorChange(){
      //添加需要判断改颜色的元素
      if (colorChange(2000,'current-status-dtjg')) {
        $("#current-status-dtjg").css({
              // 改为红色
              color:'red'
        })
      } ;
      if(colorChange(140,'target-relative')){
         $("#target-relative").css({
              // 改为绿色
              color:'green'
        })
      }
   }

    initColorChange();
    $(".bi-view-open").click(function(e){
      e.stopPropagation();
      var that = $(this);
      if(that.hasClass("bi-open-change")){
        that.removeClass("bi-open-change");
      } else {
        that.addClass("bi-open-change");
      }
      $(".current-status-detail").fadeToggle(400,"swing");
    });

    function showUnusualDetail(){
      $(".unusual-status canvas").hover(function(){
        $(this).prev().toggle();
      })
    };
    showUnusualDetail();
    //动态添加下三角按钮
    function addBottomIconRolled(){
      var $mainDiv = $("#content-main");
      var addHtml = '<div class="bottom-icon-rolled " id="bottom-icon-rolled"></div>';
          $mainDiv. append(addHtml);
    }
    addBottomIconRolled();
    //点击展开评论区域
    var showTag = true;
    var documentH = $("#content-main").height();
    var bb =documentH;
    function showCommentsSection(){
      $("#bottom-icon-rolled").click(function(e){
          e.stopPropagation;
          //获取文档容器的高度
        var  setDocumentH = documentH*0.6,
             that = $(this);
         if (showTag) {
            $(".CommentsSection").slideDown(function(){
            $("#content-main").css({
              'height':setDocumentH+'px',
              'overflow-y':'auto'
            });
             that.css({
             "background-position":"0px -135px"
             });
             showTag = false;
            });
         } else {

          $(".CommentsSection").slideUp(function(){
            $("#content-main").css({
              'height':documentH+'px',
              'overflow-y':'hidden'
            });
            that.css({
            "background-position":"0px -129px"
             });
             location.reload(true);
             showTag = true;
            });     
          } 
      })
    }
    showCommentsSection();
  })(jQuery,window,document)//闭包一结束

